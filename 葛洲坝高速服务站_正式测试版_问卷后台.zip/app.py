from flask import Flask, request, render_template, redirect, url_for, send_file
import sqlite3, csv, io, os
from datetime import datetime

app=Flask(__name__)
DB=os.environ.get("DB_PATH","survey.db")
ADMIN_KEY=os.environ.get("ADMIN_KEY","123456")

def db():
    c=sqlite3.connect(DB)
    c.execute("""CREATE TABLE IF NOT EXISTS responses(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      created_at TEXT NOT NULL,
      q1 TEXT NOT NULL,q2 TEXT NOT NULL,q3 TEXT NOT NULL,
      q4 TEXT NOT NULL,q5 TEXT NOT NULL,suggestion TEXT)""")
    c.commit()
    return c

@app.route("/",methods=["GET","POST"])
def survey():
    if request.method=="POST":
        vals=[request.form.get(f"q{i}","") for i in range(1,6)]
        suggestion=request.form.get("suggestion","")
        if not all(vals): return "请完整填写前5题",400
        c=db()
        c.execute("""INSERT INTO responses(created_at,q1,q2,q3,q4,q5,suggestion)
                     VALUES(?,?,?,?,?,?,?)""",
                  [datetime.now().strftime("%Y-%m-%d %H:%M:%S"),*vals,suggestion])
        c.commit(); c.close()
        return render_template("thanks.html")
    return render_template("survey.html")

def auth():
    return request.args.get("key")==ADMIN_KEY

@app.route("/admin")
def admin():
    if not auth(): return "后台访问需要正确的 key",403
    c=db()
    rows=c.execute("SELECT * FROM responses ORDER BY id DESC").fetchall()
    c.close()
    return render_template("admin.html",rows=rows)

@app.route("/admin/export")
def export():
    if not auth(): return "后台访问需要正确的 key",403
    c=db(); cur=c.execute("SELECT * FROM responses ORDER BY id")
    rows=cur.fetchall(); headers=[x[0] for x in cur.description]; c.close()
    s=io.StringIO(); w=csv.writer(s); w.writerow(headers); w.writerows(rows)
    b=io.BytesIO(s.getvalue().encode("utf-8-sig")); b.seek(0)
    return send_file(b,as_attachment=True,download_name="葛洲坝服务站调查数据.csv",mimetype="text/csv")

if __name__=="__main__":
    db().close()
    app.run(host="0.0.0.0",port=int(os.environ.get("PORT","5000")))
